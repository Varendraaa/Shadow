<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.10.2" name="Test" tilewidth="512" tileheight="512" tilecount="15" columns="0" tilerendersize="grid">
 <grid orientation="orthogonal" width="1" height="1"/>
 <tile id="0">
  <image width="512" height="512" source="../Textures/Levels/12.png"/>
 </tile>
 <tile id="1">
  <image width="512" height="512" source="../Textures/Levels/13.png"/>
 </tile>
 <tile id="2">
  <image width="512" height="512" source="../Textures/Levels/14.png"/>
 </tile>
 <tile id="3">
  <image width="512" height="512" source="../Textures/Levels/15.png"/>
 </tile>
 <tile id="4">
  <image width="512" height="512" source="../Textures/Levels/16.png"/>
 </tile>
 <tile id="5">
  <image width="512" height="512" source="../Textures/Levels/17.png"/>
 </tile>
 <tile id="6">
  <image width="512" height="512" source="../Textures/Levels/18.png"/>
 </tile>
 <tile id="7">
  <image width="512" height="512" source="../Textures/Levels/19.png"/>
 </tile>
 <tile id="8">
  <image width="512" height="512" source="../Textures/Levels/20.png"/>
 </tile>
 <tile id="9">
  <image width="512" height="512" source="../Textures/Levels/21.png"/>
 </tile>
 <tile id="10">
  <image width="512" height="512" source="../Textures/Level/11.png"/>
 </tile>
 <tile id="11">
  <image width="512" height="512" source="../Textures/Level/12.png"/>
 </tile>
 <tile id="12">
  <image width="512" height="512" source="../Textures/Level/13.png"/>
 </tile>
 <tile id="13">
  <image width="512" height="512" source="../Textures/Level/14.png"/>
 </tile>
 <tile id="14">
  <image width="512" height="512" source="../Textures/Level/15.png"/>
 </tile>
</tileset>
